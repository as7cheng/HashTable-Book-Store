# files that are here are tracked with git
# and intended as the files to provide to students

# TODO: edit ../update_student_files to
# - build p3a.zip
# - copy all files from here to /p/course/cs400-deppeler/public/html-s/assignments/p3/files/files_p3a

